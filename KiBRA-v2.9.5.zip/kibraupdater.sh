#!/bin/bash
# Bash script to upgrade KiBRA package in KTBRN1 device.
IMAGEN_RO=/aufs/ro
IMAGEN_RW=

if [ -d $IMAGEN_RO ]
then
    PREFIX=$IMAGEN_RO
else
    PREFIX=$IMAGEN_RW
fi

# Python3 environment
PY3ENV=$PREFIX/opt/kirale/py3env

# Python2 environment
PY2ENV=$PREFIX/opt/kirale/py2env

# Check Linux Kernel version
current_version=$(uname -r | cut -d'-' -f 1)
min_version="5.4.63"
if [ "$(printf '%s\n' "$min_version" "$current_version" | sort -V | head -n1)" = "$min_version" ]
then
    if [ -d $PY3ENV ]
    then
        if [ -d $PY2ENV ]
        then
            # Stop KiBRA service
            service kibra stop

            # Upgrade KiBRA package
            #rm -rf /opt/kirale/kibra.cfg
            #rm -rf "$PREFIX"/opt/kirale/kibra.cfg
            rm -rf "$PY3ENV"/lib/python3.7/site-packages/kibra*
            source "$PY3ENV"/bin/activate
            pip install --prefix "$PY3ENV" --no-warn-script-location ./kibra*.whl 
            deactivate

            # Upgrade WebAdmin package
            #rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti.plugin.branding*
            #rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti_plugin_branding
            rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti.plugin.auth_users*
            rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti_plugin_auth_users
            rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti.plugin.kibra*
            rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti_plugin_kibra
            rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti.plugin.network*
            rm -rf "$PY2ENV"/lib/python2.7/site-packages/ajenti_plugin_network
            source "$PY2ENV"/bin/activate
			# Install required package
			pip install --prefix "$PY2ENV" --no-warn-script-location ./scrypt-0.8.18*.whl
			sleep 5
			# Fix Ajenti Terminal plugin
			pyte_ver=$(pip show pyte --no-python-version-warning | grep Version | cut -d " " -f 2)
			if [ "$pyte_ver" != "0.8.0" ]
			then
				sed -i "/Requires-Dist: pyte/c Requires-Dist: pyte (==0.8.0)" "$PY2ENV"/lib/python2.7/site-packages/ajenti.plugin.terminal-0.36.dist-info/METADATA
				sed -i "/pyte==/c pyte==0.8.0 # Use dicts instead of lists" "$PY2ENV"/lib/python2.7/site-packages/ajenti_plugin_terminal/requirements.txt
				pip install --prefix "$PY2ENV" --no-warn-script-location ./backports.functools_lru_cache*.whl ./wcwidth-0.2.5*.whl
				deactivate
				sleep 5
				source "$PY2ENV"/bin/activate				
				pip install --upgrade --prefix "$PY2ENV" --no-warn-script-location ./pyte-0.8.0*.whl
			fi
			# Install plugins from scratch
            pip install --prefix "$PY2ENV" --no-warn-script-location ./ajenti.plugin.*.whl			
            deactivate

			#Garbage
			rm -rf "$PY2ENV"/lib/python2.7/site-packages/pyte-0.4.9.dist-info
            #Update rsync-filter
            /bin/cp -f ./rsync-filter "$PREFIX"/opt/kirale/
			#Fix slow booting due to network.service
			sed -i '/auto eth0/c allow-hotplug eth0' "$PREFIX"/etc/network/interfaces			
			#Fix Avahi
            service avahi-daemon stop
            /bin/cp -f ./libavahi-core.so.7.0.2 "$PREFIX"/usr/lib/arm-linux-gnueabihf/
			sleep 2
			
			#Update WiFi drivers
			if [ -d $IMAGEN_RO ]
			then
				if [ -f ./chroot_script.sh ]
				then
					chmod +x ./chroot_script.sh
					cp ./*.deb "$IMAGEN_RO"/tmp
					mount -B /dev "$IMAGEN_RO"/dev
					chroot "$IMAGEN_RO" /bin/sh < ./chroot_script.sh
					umount -lf "$IMAGEN_RO"/dev
					exit 0
				else
					echo "This is not a valid package to upgrade KiBRA"
					exit 1
				fi
			else
				apt remove -y armbian-firmware
				apt install -u -y ./*.deb
			fi
        else
            echo "This is not a valid image to install KiBRA"
            exit 1
        fi
    else
        echo "This is not a valid image to install KiBRA"
        exit 1
    fi
else
    echo "This is not a valid image to install KiBRA"
    exit 1
fi
