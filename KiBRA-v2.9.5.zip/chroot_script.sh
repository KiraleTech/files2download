#!/bin/bash
# Bash script to upgrade WiFi drivers in KTBRN1 device.
cd /tmp
mount -t devpts none /dev/pts
apt remove -y armbian-firmware
apt install -u -y ./*.deb
rm -rf ./*.deb
update-alternatives --set regulatory.db /lib/firmware/regulatory.db-upstream
umount /dev/pts || umount -lf /dev/pts
